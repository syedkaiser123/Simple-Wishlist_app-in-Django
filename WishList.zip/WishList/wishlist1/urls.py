
from django.conf.urls import url
from django.contrib import admin
from . import views

urlpatterns = [
    url(r'^$', views.home, name='home'),
    url(r'^home', views.home, name='home'),
    url(r'^add', views.add, name='add'),
    
    url(r'^delete_wish(?P<id>\d+)', views.delete_wish, name='delete_wish'),
]
