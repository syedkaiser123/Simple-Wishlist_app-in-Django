# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

class wishes(models.Model):													#table name as 'wishes'

	wishname = models.CharField(max_length=100)
	date_posted = models.DateTimeField(auto_now_add=True)					#create a date Time field with automatic as true

	def __str__(self):
		return self.wishname

	class Meta:
		verbose_name_plural = 'wishes'						#for correcting the auto append of 's' to the table name by django