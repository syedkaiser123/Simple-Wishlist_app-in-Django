# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
import sqlite3
from .models import wishes
from django.contrib import messages


def home(request):

	entries = wishes.objects.order_by('-date_posted')

	context = {'entries': entries}

	return render(request, 'home.html', context)

def add(request):

	if request.method == 'POST':
		
		value = request.POST.get('addwish')

		wishesObject = wishes.objects.create(wishname=value)
		wishesObject.save() 


		entries = wishes.objects.order_by('-date_posted')

		context = {'entries': entries}

		return render(request, 'home.html', context)



	else:

		return render(request, 'home.html')		



def delete_wish(request, id):

	instance = get_object_or_404(wishes, id=id)
	instance.delete()
	return redirect('home.html')




